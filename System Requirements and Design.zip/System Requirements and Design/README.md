# Capstone Main Project: Phase 1

# CodeX Crew

This directory will have all the system requirements and design for this project
